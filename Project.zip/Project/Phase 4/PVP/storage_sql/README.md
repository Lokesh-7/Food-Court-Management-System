>>>> Both the files FoodDatabase.sql and Functions.py should be in the same directory.
>>>>For running the code type "python3 Functions.py".
>>>>After running the code you will be asked about user,host,port,password.Please enter the details asked to get the access of the database.